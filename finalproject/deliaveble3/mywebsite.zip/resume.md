![photo](pc1.jpg)

# Esmil Lantigua 

 **Paterson NJ** 
 *Contact information*
**Cell Phone**
 *551 262 7880*
 **Gmail**
  *esmil5599@gmail.com*
<hr>

 # Professional Summary

  Material Designation in Warehouse Locations and forklift operator.* Experience with organic gluten free materials 
  Experience with OTC/ API material Experience with Raw Materials Inspector, *system computer knowledge Laboratory notebook knowledge
  Inspection of materials expired.
  <hr>

# Work Experience

ENGLEWOOD LAB- TOTOWA,NJ
OCTUBER 2019 TO MAY 2021**

Material handler, Quality Control inspector
shipping and receiving raw material
 
 **Forklift Operator
 KARI-OUT TOTOWA-NJ
 JUNE 2021 TO PRESENT**

*unloading truck materials picking services to satisfy customer needs
warehouse cycle counter assistant  responder to a warehouse discrepancies with finish good raw materials  item*
<hr>

# Education
 
**Manchester Regional High School**

High School Diploma 2019

**Passaic CountyComminity College**

English Studies Diploma 2021

Associate Degree (in progress..)
2023-present

# skills

<hr>

**Organizational warehouse management**

  *I have more then more four years of experience leading warehouse organization inventory  management solves discrepancies and problems with the  cycle counter system*

*skills with offices 365 and power points,word Excell
customers services communications*

## Additioal links
<hr>


* [ Facebook profile](https://www.facebook.com/esmil.cruz.18/)

* [ Instagram profile](https://www.instagram.com/)
* [second email] (esmil5599@gmail.com)